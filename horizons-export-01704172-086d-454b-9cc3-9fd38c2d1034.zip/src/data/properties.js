// This file serves as a reference for static data structure with UUIDs
export const properties = [
  {
    id: '11111111-1111-4111-8111-111111111111',
    title: 'Luxury Penthouse Bogotá',
    location: 'Bogotá',
    priceCOP: 3400000000,
    priceUSD: 850000,
    bedrooms: 3,
    bathrooms: 3,
    size: 250,
    type: 'Penthouse',
    yearBuilt: 2021,
    description: 'Stunning penthouse with panoramic city views in the heart of Bogotá. Features modern design, premium finishes, and access to world-class amenities.',
    features: ['Panoramic Views', 'Gym', 'Pool', 'Parking', '24/7 Security', 'Smart Home'],
    images: [
      'https://images.unsplash.com/photo-1655757781350-7963acc6d873',
      'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9',
      'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c'
    ],
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
  },
  {
    id: '22222222-2222-4222-8222-222222222222',
    title: 'Beachfront Villa Cartagena',
    location: 'Cartagena',
    priceCOP: 4800000000,
    priceUSD: 1200000,
    bedrooms: 4,
    bathrooms: 4,
    size: 350,
    type: 'Villa',
    yearBuilt: 2020,
    description: 'Exclusive beachfront villa in Cartagena with private beach access. Perfect blend of colonial charm and modern luxury.',
    features: ['Beach Access', 'Ocean View', 'Pool', 'Garden', 'Terrace', 'BBQ Area'],
    images: [
      'https://images.unsplash.com/photo-1593321706583-6a76bdbee0f1',
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750',
      'https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde'
    ],
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
  },
  {
    id: '33333333-3333-4333-8333-333333333333',
    title: 'Modern Apartment Medellín',
    location: 'Medellín',
    priceCOP: 1800000000,
    priceUSD: 450000,
    bedrooms: 2,
    bathrooms: 2,
    size: 120,
    type: 'Apartment',
    yearBuilt: 2022,
    description: 'Contemporary apartment in El Poblado, Medellín\'s most exclusive neighborhood. Walking distance to restaurants and shops.',
    features: ['City View', 'Gym', 'Coworking Space', 'Parking', 'Pet Friendly', 'Balcony'],
    images: [
      'https://images.unsplash.com/photo-1641567682015-7a13a9d54e26',
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c',
      'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea'
    ],
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
  },
  {
    id: '44444444-4444-4444-8444-444444444444',
    title: 'Coffee Estate Investment',
    location: 'Eje Cafetero',
    priceCOP: 2400000000,
    priceUSD: 600000,
    bedrooms: 5,
    bathrooms: 4,
    size: 500,
    type: 'Estate',
    yearBuilt: 2018,
    description: 'Working coffee plantation with stunning views and multiple revenue streams. Includes main house and guest accommodations.',
    features: ['Coffee Farm', 'Mountain Views', 'Multiple Buildings', 'Investment Opportunity', 'Land', 'Nature'],
    images: [
      'https://images.unsplash.com/photo-1691058428335-25943e473db5',
      'https://images.unsplash.com/photo-1500382017468-9049fed747ef',
      'https://images.unsplash.com/photo-1464820453369-31d2c0b651af'
    ],
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
  },
  {
    id: '55555555-5555-4555-8555-555555555555',
    title: 'Luxury Condo Bogotá',
    location: 'Bogotá',
    priceCOP: 3800000000,
    priceUSD: 950000,
    bedrooms: 3,
    bathrooms: 3,
    size: 280,
    type: 'Condo',
    yearBuilt: 2022,
    description: 'Premium condominium in Rosales, offering the finest in luxury living with unparalleled amenities and services.',
    features: ['Concierge', 'Spa', 'Wine Cellar', 'Gym', 'Parking', 'Storage'],
    images: [
      'https://images.unsplash.com/photo-1665406811013-462289b5a7d2',
      'https://images.unsplash.com/photo-1600607687644-aac4c3eac7f4',
      'https://images.unsplash.com/photo-1600573472550-8090b5e0745e'
    ],
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
  },
  {
    id: '66666666-6666-4666-8666-666666666666',
    title: 'Caribbean Beachfront',
    location: 'Santa Marta',
    priceCOP: 6000000000,
    priceUSD: 1500000,
    bedrooms: 5,
    bathrooms: 5,
    size: 400,
    type: 'Villa',
    yearBuilt: 2021,
    description: 'Ultimate Caribbean paradise with direct beach access and breathtaking ocean views. Perfect for luxury living or vacation rental investment.',
    features: ['Private Beach', 'Infinity Pool', 'Ocean View', 'Entertainment Area', 'Chef Kitchen', 'Staff Quarters'],
    images: [
      'https://images.unsplash.com/photo-1663601982929-51e28aab0444',
      'https://images.unsplash.com/photo-1499793983690-e29da59ef1c2',
      'https://images.unsplash.com/photo-1615460549969-36fa19521a4f'
    ],
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
  },
  {
    id: '77777777-7777-4777-8777-777777777777',
    title: 'Mountain View Estate',
    location: 'Medellín',
    priceCOP: 2800000000,
    priceUSD: 700000,
    bedrooms: 4,
    bathrooms: 3,
    size: 350,
    type: 'House',
    yearBuilt: 2019,
    description: 'Spectacular estate overlooking the Aburrá Valley with modern architecture and sustainable features.',
    features: ['Mountain Views', 'Solar Panels', 'Garden', 'Home Office', 'Parking', 'Security'],
    images: [
      'https://images.unsplash.com/photo-1582784897802-327242cba336',
      'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9',
      'https://images.unsplash.com/photo-1600585154526-990dced4db0d'
    ],
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
  },
  {
    id: '88888888-8888-4888-8888-888888888888',
    title: 'Penthouse with City View',
    location: 'Bogotá',
    priceCOP: 4400000000,
    priceUSD: 1100000,
    bedrooms: 3,
    bathrooms: 4,
    size: 300,
    type: 'Penthouse',
    yearBuilt: 2023,
    description: 'Brand new penthouse with 360-degree city views, rooftop terrace, and the finest finishes available.',
    features: ['Rooftop Terrace', 'City Views', 'Jacuzzi', 'Wine Cellar', 'Smart Home', 'Premium Finishes'],
    images: [
      'https://images.unsplash.com/photo-1641058576664-5d1c61512c47',
      'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c',
      'https://images.unsplash.com/photo-1600566752355-35792bedcfea'
    ],
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
  }
];