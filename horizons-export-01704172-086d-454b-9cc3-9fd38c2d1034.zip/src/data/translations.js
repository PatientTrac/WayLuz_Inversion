export const EXCHANGE_RATE = 4000;

export const translations = {
  en: {
    currency: {
      cop: 'COP',
      usd: 'USD',
      priceCop: 'Price in COP',
      priceUsd: 'Price in USD',
      exchangeRate: 'Exchange Rate approx.'
    },
    nav: {
      home: 'Home',
      about: 'About',
      properties: 'Properties',
      contact: 'Contact',
      admin: 'Admin'
    },
    admin: {
      title: 'Admin',
      titleAccent: 'Panel',
      tabs: {
        list: 'Property List',
        add: 'Add Property',
        edit: 'Edit Property'
      },
      actions: {
        edit: 'Edit',
        delete: 'Delete',
        save: 'Save Property',
        update: 'Update Property',
        cancel: 'Cancel',
        addPhoto: 'Add Photo',
        addVideo: 'Add Video'
      },
      form: {
        name: 'Property Name',
        location: 'Location',
        price: 'Price',
        priceCOP: 'Price (COP)',
        priceUSD: 'Price (USD)',
        area: 'Area (m²)',
        bedrooms: 'Bedrooms',
        bathrooms: 'Bathrooms',
        type: 'Property Type',
        year: 'Year Built',
        desc: 'Description',
        amenities: 'Amenities (comma separated)',
        photos: 'Photos',
        videos: 'Videos',
        url: 'URL',
        title: 'Title'
      },
      upload: {
        title: 'Property Images',
        dropzone: 'Drag & Drop images here, or click to select',
        supports: 'Supports JPG, PNG, WebP (Max 5MB)',
        uploading: 'Uploading...',
        success: 'Image uploaded successfully',
        error: 'Error uploading image',
        galleryTitle: 'Gallery Management',
        setFeatured: 'Set as Featured',
        featured: 'Featured',
        delete: 'Delete',
        confirmDelete: 'Are you sure you want to delete this image?',
        storageUsage: 'Storage Usage',
        count: 'Images'
      }
    },
    contact: {
      address: 'Ave 10 Calle 48 Interior 4, Los Patios, Colombia',
      phone: '+57 320 9937784',
      hoursLabel: 'Business Hours',
      hours: 'Monday - Saturday, 8:00 AM - 4:30 PM',
      callNow: 'Call Now',
      emailUs: 'Email Us',
      visitUs: 'Visit Us',
      callUs: 'Call Us',
      emailUsTitle: 'Email Us',
      sendMessage: 'Send Message'
    },
    home: {
      heroTitle: 'Discover Colombia: Your Gateway to',
      heroTitleAccent: 'Smart Investments',
      heroSubtitle: 'Unlock premium real estate opportunities in Colombia\'s most vibrant cities',
      exploreBtn: 'Explore Properties',
      contactBtn: 'Contact Us',
      whyInvest: 'Why Invest in',
      whyInvestAccent: 'Colombia',
      whyInvestDesc: 'Discover the advantages that make Colombia a prime destination for real estate investment',
      features: {
        economic: { title: 'Economic Growth', desc: 'Colombia\'s economy has shown consistent growth, making it an attractive destination for real estate investments with strong returns.' },
        market: { title: 'Real Estate Market', desc: 'A thriving property market with diverse opportunities from luxury condos to beachfront estates, offering excellent value.' },
        nature: { title: 'Natural Beauty', desc: 'From Caribbean beaches to Andean mountains, Colombia offers stunning landscapes that enhance property values.' },
        culture: { title: 'Cultural Heritage', desc: 'Rich history and vibrant culture create unique investment opportunities in historic and modern properties alike.' }
      },
      readyTitle: 'Ready to Start Your Investment Journey?',
      readyDesc: 'Let our experts guide you through Colombia\'s most promising real estate opportunities',
      viewAllBtn: 'View All Properties',
      scheduleBtn: 'Schedule Consultation'
    },
    about: {
      title: 'About',
      subtitle: 'Strategic Investment Partners in Norte de Santander',
      missionTitle: 'Our Mission',
      missionStatement: 'WayLuz Inversions SAS is dedicated to transforming the real estate investment landscape in Norte de Santander and throughout Colombia. Our mission is to provide a secure, transparent, and highly profitable gateway for international and local investors. We specialize in identifying high-growth potential properties in strategic locations like Los Patios and Cúcuta, capitalizing on the dynamic economic activities of the border region. By combining rigorous market analysis with unwavering ethical standards, we ensure that every investment not only secures capital but builds lasting wealth. We are more than a real estate agency; we are your strategic partners in building a prosperous future in one of Colombia\'s most promising regions.',
      map: {
        title: 'Strategic Location',
        subtitle: 'Located in the heart of Norte de Santander, a key economic hub bordering Venezuela.',
        losPatios: 'Los Patios (HQ)',
        cucuta: 'Cúcuta Metropolitan Area',
        venezuela: 'Venezuela Border',
        region: 'Norte de Santander',
        colombia: 'Colombia'
      },
      cta: {
        title: 'Invest in the Future',
        desc: 'Join a growing network of visionary investors capitalizing on the unique opportunities of the Colombian border region.',
        button: 'Contact Us Today'
      }
    },
    properties: {
      title: 'Our',
      titleAccent: 'Properties',
      subtitle: 'Discover exceptional real estate opportunities across Colombia\'s most desirable locations',
      noProperties: 'No properties found.',
      details: 'View Details',
      beds: 'Beds',
      baths: 'Baths',
      size: 'm²',
      price: 'Price'
    },
    propertyDetail: {
      back: 'Back to Properties',
      type: 'Type',
      location: 'Location',
      yearBuilt: 'Year Built',
      size: 'Size',
      about: 'About This Property',
      features: 'Features & Amenities',
      tour: 'Property Tour',
      interested: 'Interested in this property?',
      scheduleTour: 'Schedule Tour',
      contactAgent: 'Contact Agent',
      similar: 'Similar Properties in'
    },
    fincaPage: {
      title: 'Spectacular FINCA Estate - Aerial View',
      heroTitle: 'Spectacular FINCA Estate',
      description: 'Experience the breathtaking beauty of the Colombian countryside in this exclusive estate. Surrounded by lush coffee plantations and rolling hills, this property offers a unique blend of traditional charm and modern luxury.',
      location: 'Rural Colombia',
      featuresTitle: 'Property Features',
      galleryTitle: 'Photo Gallery',
      videoTitle: 'Video Tours',
      scheduleTour: 'Schedule Tour',
      contactAgent: 'Contact Agent',
      backLink: 'Back to Properties',
      specs: {
        bedrooms: 'Bedrooms',
        bathrooms: 'Bathrooms',
        area: 'Area',
        amenities: 'Amenities'
      },
      amenitiesList: {
        coffee: 'Coffee Plantation',
        mountain: 'Mountain Views',
        guest: 'Guest House',
        stable: 'Stable',
        pool: 'Swimming Pool',
        fruit: 'Fruit Trees'
      }
    },
    footer: {
      desc: 'Empowering investors with premium real estate opportunities in Colombia',
      quickLinks: 'Quick Links',
      contact: 'Contact Us',
      follow: 'Follow Us',
      rights: 'All rights reserved.'
    }
  },
  es: {
    currency: {
      cop: 'COP',
      usd: 'USD',
      priceCop: 'Precio en COP',
      priceUsd: 'Precio en USD',
      exchangeRate: 'Tasa de Cambio aprox.'
    },
    nav: {
      home: 'Inicio',
      about: 'Nosotros',
      properties: 'Propiedades',
      contact: 'Contacto',
      admin: 'Admin'
    },
    admin: {
      title: 'Panel de',
      titleAccent: 'Administración',
      tabs: {
        list: 'Lista de Propiedades',
        add: 'Agregar Propiedad',
        edit: 'Editar Propiedad'
      },
      actions: {
        edit: 'Editar',
        delete: 'Eliminar',
        save: 'Guardar Propiedad',
        update: 'Actualizar Propiedad',
        cancel: 'Cancelar',
        addPhoto: 'Agregar Foto',
        addVideo: 'Agregar Video'
      },
      form: {
        name: 'Nombre de Propiedad',
        location: 'Ubicación',
        price: 'Precio',
        priceCOP: 'Precio (COP)',
        priceUSD: 'Precio (USD)',
        area: 'Área (m²)',
        bedrooms: 'Habitaciones',
        bathrooms: 'Baños',
        type: 'Tipo de Propiedad',
        year: 'Año de Construcción',
        desc: 'Descripción',
        amenities: 'Amenidades (separadas por coma)',
        photos: 'Fotos',
        videos: 'Videos',
        url: 'URL',
        title: 'Título'
      },
      upload: {
        title: 'Imágenes de la Propiedad',
        dropzone: 'Arrastra imágenes aquí, o haz clic para seleccionar',
        supports: 'Soporta JPG, PNG, WebP (Máx 5MB)',
        uploading: 'Subiendo...',
        success: 'Imagen subida exitosamente',
        error: 'Error subiendo imagen',
        galleryTitle: 'Gestión de Galería',
        setFeatured: 'Destacar',
        featured: 'Destacada',
        delete: 'Eliminar',
        confirmDelete: '¿Estás seguro de querer eliminar esta imagen?',
        storageUsage: 'Uso de Almacenamiento',
        count: 'Imágenes'
      }
    },
    contact: {
      address: 'Ave 10 Calle 48 Interior 4, Los Patios, Colombia',
      phone: '+57 320 9937784',
      hoursLabel: 'Horario de Atención',
      hours: 'Lunes - Sábado, 8:00 AM - 4:30 PM',
      callNow: 'Llamar Ahora',
      emailUs: 'Envíanos un Email',
      visitUs: 'Visítanos',
      callUs: 'Llámanos',
      emailUsTitle: 'Escríbenos',
      sendMessage: 'Enviar Mensaje'
    },
    home: {
      heroTitle: 'Descubre Colombia: Tu Puerta a',
      heroTitleAccent: 'Inversiones Inteligentes',
      heroSubtitle: 'Desbloquea oportunidades inmobiliarias premium en las ciudades más vibrantes de Colombia',
      exploreBtn: 'Explorar Propiedades',
      contactBtn: 'Contáctanos',
      whyInvest: '¿Por qué invertir en',
      whyInvestAccent: 'Colombia',
      whyInvestDesc: 'Descubre las ventajas que hacen de Colombia un destino principal para la inversión inmobiliaria',
      features: {
        economic: { title: 'Crecimiento Económico', desc: 'La economía de Colombia ha mostrado un crecimiento constante, convirtiéndola en un destino atractivo para inversiones inmobiliarias con fuertes retornos.' },
        market: { title: 'Mercado Inmobiliario', desc: 'Un mercado inmobiliario próspero con diversas oportunidades, desde condominios de lujo hasta fincas frente al mar, ofreciendo excelente valor.' },
        nature: { title: 'Belleza Natural', desc: 'Desde playas caribeñas hasta montañas andinas, Colombia ofrece paisajes impresionantes que aumentan el valor de las propiedades.' },
        culture: { title: 'Patrimonio Cultural', desc: 'La rica historia y cultura vibrante crean oportunidades de inversión únicas tanto en propiedades históricas como modernas.' }
      },
      readyTitle: '¿Listo para Iniciar tu Viaje de Inversión?',
      readyDesc: 'Deja que nuestros expertos te guíen a través de las oportunidades inmobiliarias más prometedoras de Colombia',
      viewAllBtn: 'Ver Todas las Propiedades',
      scheduleBtn: 'Agendar Consulta'
    },
    about: {
      title: 'Sobre',
      subtitle: 'Socios Estratégicos de Inversión en Norte de Santander',
      missionTitle: 'Nuestra Misión',
      missionStatement: 'WayLuz Inversions SAS se dedica a transformar el panorama de inversión inmobiliaria en Norte de Santander y en toda Colombia. Nuestra misión es proporcionar una puerta de entrada segura, transparente y altamente rentable para inversionistas locales e internacionales. Nos especializamos en identificar propiedades con alto potencial de crecimiento en ubicaciones estratégicas como Los Patios y Cúcuta, capitalizando las dinámicas actividades económicas de la región fronteriza. Al combinar un riguroso análisis de mercado con estándares éticos inquebrantables, aseguramos que cada inversión no solo asegure el capital, sino que construya riqueza duradera. Somos más que una agencia inmobiliaria; somos sus socios estratégicos en la construcción de un futuro próspero en una de las regiones más prometedoras de Colombia.',
      map: {
        title: 'Ubicación Estratégica',
        subtitle: 'Ubicados en el corazón de Norte de Santander, un centro económico clave fronterizo con Venezuela.',
        losPatios: 'Los Patios (Sede)',
        cucuta: 'Área Metropolitana de Cúcuta',
        venezuela: 'Frontera con Venezuela',
        region: 'Norte de Santander',
        colombia: 'Colombia'
      },
      cta: {
        title: 'Invierte en el Futuro',
        desc: 'Únete a una creciente red de inversionistas visionarios que capitalizan las oportunidades únicas de la región fronteriza colombiana.',
        button: 'Contáctanos Hoy'
      }
    },
    properties: {
      title: 'Nuestras',
      titleAccent: 'Propiedades',
      subtitle: 'Descubre oportunidades inmobiliarias excepcionales en las ubicaciones más deseables de Colombia',
      noProperties: 'No se encontraron propiedades.',
      details: 'Ver Detalles',
      beds: 'Hab',
      baths: 'Baños',
      size: 'm²',
      price: 'Precio'
    },
    propertyDetail: {
      back: 'Volver a Propiedades',
      type: 'Tipo',
      location: 'Ubicación',
      yearBuilt: 'Año de Construcción',
      size: 'Tamaño',
      about: 'Sobre esta Propiedad',
      features: 'Características y Amenidades',
      tour: 'Tour de la Propiedad',
      interested: '¿Interesado en esta propiedad?',
      scheduleTour: 'Agendar Visita',
      contactAgent: 'Contactar Agente',
      similar: 'Propiedades Similares en'
    },
    fincaPage: {
      title: 'Espectacular Finca - Vista Aérea',
      heroTitle: 'Espectacular Finca',
      description: 'Experimente la impresionante belleza del campo colombiano en esta finca exclusiva. Rodeada de exuberantes plantaciones de café y colinas ondulantes, esta propiedad ofrece una mezcla única de encanto tradicional y lujo moderno.',
      location: 'Colombia Rural',
      featuresTitle: 'Características de la Propiedad',
      galleryTitle: 'Galería de Fotos',
      videoTitle: 'Recorridos en Video',
      scheduleTour: 'Agendar Visita',
      contactAgent: 'Contactar Agente',
      backLink: 'Volver a Propiedades',
      specs: {
        bedrooms: 'Habitaciones',
        bathrooms: 'Baños',
        area: 'Área',
        amenities: 'Amenidades'
      },
      amenitiesList: {
        coffee: 'Plantación de Café',
        mountain: 'Vistas a la Montaña',
        guest: 'Casa de Huéspedes',
        stable: 'Establo',
        pool: 'Piscina',
        fruit: 'Árboles Frutales'
      }
    },
    footer: {
      desc: 'Empoderando inversionistas con oportunidades inmobiliarias premium en Colombia',
      quickLinks: 'Enlaces Rápidos',
      contact: 'Contáctanos',
      follow: 'Síguenos',
      rights: 'Todos los derechos reservados.'
    }
  }
};