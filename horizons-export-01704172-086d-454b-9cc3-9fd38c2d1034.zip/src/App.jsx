import React, { useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import HomePage from '@/pages/HomePage';
import PropertiesPage from '@/pages/PropertiesPage';
import PropertyDetailPage from '@/pages/PropertyDetailPage';
import AboutPage from '@/pages/AboutPage';
import ContactPage from '@/pages/ContactPage';
import AdminLoginPage from '@/pages/AdminLoginPage';
import AdminPanel from '@/pages/AdminPanel';
import FincaAerialViewPage from '@/pages/FincaAerialViewPage';
import DiagnosticPage from '@/pages/DiagnosticPage';
import { Toaster } from '@/components/ui/toaster';
import { SupabaseAuthProvider } from '@/contexts/SupabaseAuthContext';
import { LanguageProvider } from '@/context/LanguageContext';
import { AdminAuthProvider, useAdminAuth } from '@/context/AdminAuthContext';
// Note: ProtectedRoute is replaced by direct auth handling in AdminPanel for clearer redirection logic
import ProtectedRoute from '@/components/ProtectedRoute';

const EditModeManager = () => {
  const { setEditMode } = useAdminAuth();
  const location = useLocation();

  useEffect(() => {
    if (!location.pathname.startsWith('/admin')) {
      setEditMode(false);
    }
  }, [location, setEditMode]);

  useEffect(() => {
    const handleUnload = () => {
      setEditMode(false);
    };

    window.addEventListener('beforeunload', handleUnload);
    return () => {
      window.removeEventListener('beforeunload', handleUnload);
    };
  }, [setEditMode]);

  return null;
};

const App = () => {
  return (
    <LanguageProvider>
      <SupabaseAuthProvider>
        <AdminAuthProvider>
          <Helmet>
            <title>WayLuz Inversions SAS</title>
            <meta name="description" content="WayLuz Inversions SAS - Premium Real Estate Investments in Colombia" />
          </Helmet>
          <EditModeManager />
          <div className="min-h-screen bg-gray-50 flex flex-col font-sans text-gray-900">
            <Navigation />
            <main className="flex-grow">
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/properties" element={<PropertiesPage />} />
                {/* Updated route to use slug instead of ID */}
                <Route path="/properties/:slug" element={<PropertyDetailPage />} />
                <Route path="/about" element={<AboutPage />} />
                <Route path="/contact" element={<ContactPage />} />
                <Route path="/finca-aerial" element={<FincaAerialViewPage />} />
                
                {/* Admin Routes */}
                <Route path="/admin-login" element={<AdminLoginPage />} />
                
                {/* 
                  We render AdminPanel directly for /admin/* 
                  The AdminPanel component itself handles authentication checks and redirects
                  to /admin-login if necessary.
                */}
                <Route path="/admin/*" element={<AdminPanel />} />

                {/* System Diagnostic Route */}
                <Route path="/diagnostic" element={<DiagnosticPage />} />
              </Routes>
            </main>
            <Footer />
            <Toaster />
          </div>
        </AdminAuthProvider>
      </SupabaseAuthProvider>
    </LanguageProvider>
  );
};

export default App;